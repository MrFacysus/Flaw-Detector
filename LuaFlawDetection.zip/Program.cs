﻿using System;
using System.IO;

namespace LuaFlawDetection
{
    class Program
    {
        static void Output(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(text);
            Console.ForegroundColor = ConsoleColor.White;
        }
        static void Main(string[] args)
        {
            string path;
            string operation;
            string filetext;
            string[] lines;
            string[] Defined = { };
            int DefSize = 1;
            int Flaws = 0;

            bool DisabledDetection = false;
            bool ChangesDetection = false;
            bool FPSUnlockDetection = false;
            bool GodmodeDetection = false;
            bool HipHeightDetection = false;
            bool WalkSpeedDetection = false;
            bool JumpPowerDetection = false;
            bool NoclipDetection = false;
            bool ConsoleOutputDetection = false;
            bool NilParenting = false;
            bool GuiDetection = false;
            bool CoreGui = false;

            bool Wait = false;

            Output("Please input a script");
            path = Console.ReadLine();

            filetext = File.ReadAllText(path);

            lines = filetext.Split(
               new[] { "\r\n", "\r", "\n" },
                StringSplitOptions.None
            );
            Output("Doing Line Analysis \n");
            for (int I = 0 ; I < lines.Length ; I++)
            {
                operation = lines[I];

                if (operation.StartsWith("local"))
                {
                    Array.Resize(ref Defined, DefSize);
                    Defined[DefSize - 1] = (operation.Split("local ")[1]).Split("=")[0];
                    DefSize++;
                }
                if (operation.StartsWith("wait"))
                {
                    Wait = true;
                }
                if (operation.StartsWith("game.") && operation.Contains(":"))
                {
                    Output("Changing these values can be reverted in line " + (I + 1));
                    Flaws++;
                }
                if (operation.StartsWith("local") && operation.Contains("game") && !operation.Contains("GetService"))
                {
                    Output("Indexing flaw in line " + (I+1) + " with " + operation.Split("game.")[1]);
                    Flaws++;
                }
                if (!operation.StartsWith("local") && Array.Exists(Defined,s => s.Equals(operation.Split("=")[0])) == true && operation.Contains("game"))
                {
                    Output("Not localising in line " + (I + 1) + " the " + operation.Split(" = ")[0] + "variable");
                    Flaws++;
                }
                if (operation.StartsWith("local") && operation.Contains("="))
                {
                    Output("Constants can be edited, removed and misindexed in line " + (I + 1));
                    Flaws++;
                }
                if ((operation.Contains("FireServer") || operation.Contains("InvokeServer")) && (operation.Split("(")[1]).Split(")")[0] == "" || Wait == true)
                {
                    Output("Unprotected Remote calling in line " + (I + 1));
                    Flaws++;
                    Wait = false;
                }
                if (operation.Contains("require("))
                {
                    Output("Loding module scripts that can be edited and unloaded in line " + (I + 1) + " with " + (operation.Split("(")[1]).Split(")")[0] + " module script");
                    Flaws++;
                }
                if (operation.Contains("function"))
                {
                    Output("Function can be replaced, edited and tampered with in line " + (I + 1));
                    Flaws++;
                }
                if (operation.Contains(".Disabled"))
                {
                    DisabledDetection = true;
                }
                if (operation.Contains(".Changed"))
                {
                    ChangesDetection = true;
                }
                if (operation.Contains(".Name =="))
                {
                    Output("Name detection can be bypassed in line " + (I + 1));
                    Flaws++;
                }
                if (operation.Contains(".Parent")  || operation.Contains(":FindFirstChildOfClass") || operation.Contains(":FindFirstChild") || operation.Contains(":FindFirstAncestor") || operation.Contains(":FindFirstAncestorOfClass") || operation.Contains(":FindFirstAncestorWhichIsA") || operation.Contains(":FindFirstChild") || operation.Contains(":FindFirstChildWhichIsA") || operation.Contains(":WaitForChild"))
                {
                    Output("Indexing flaw in line " + (I + 1));
                    Flaws++;
                }
                if (operation.Contains(":Kick"))
                {
                    Output("Kicking from clientside in line " + (I + 1));
                    Flaws++;
                }
                if (operation.Contains("workspace") && operation.Contains(":Destroy"))
                {
                    Output("Destroying can be done before expected in line " + (I + 1));
                    Flaws++;
                }
                if (operation.Contains("tick"))
                {
                    FPSUnlockDetection = true;
                }
                if (operation.Contains("Humanoid.Health"))
                {
                    GodmodeDetection = true;
                }
                if (operation.Contains("Humanoid.HipHeight"))
                {
                    HipHeightDetection = true;
                }
                if (operation.Contains("Humanoid.WalkSpeed"))
                {
                    WalkSpeedDetection = true;
                }
                if (operation.Contains("Humanoid.JumpPower"))
                {
                    JumpPowerDetection = true;
                }
                if (operation.Contains("Humanoid:ChangeState"))
                {
                    NoclipDetection = true;
                }
                if (operation.Contains("GetLogHistory"))
                {
                    ConsoleOutputDetection = true;
                }
                if (operation.Contains(".Parent = nil"))
                {
                    NilParenting = true;
                }
                if (operation.Contains("CoreGui.ChildAdded"))
                {
                    CoreGui = true;
                }
                if (operation.Contains("PlayerGui.ChildAdded"))
                {
                    GuiDetection = true;
                }
            }
            Output(" \n Additional flaws \n ");
            if (!NilParenting)
            {
                Output("Not making security checking script's parent to NIL gives the free exploiters a chance to tamper");
                Flaws++;
            }
            if (!ConsoleOutputDetection)
            {
                Output("Not detecting output in the console allows printing out any script enviorment contents");
                Flaws++;
            }
            if (!GuiDetection)
            {
                Output("Checking for new instances in PlayerGui can stop most Gui's");
                Flaws++;
            }
            if (!CoreGui)
            {
                Output("Checking for new instances in CoreGui can stop most Gui's");
                Flaws++;
            }
            if (!WalkSpeedDetection)
            {
                Output("Not detecting speed changes can lead to speed hacks");
                Flaws++;
            }
            if (!JumpPowerDetection)
            {
                Output("Not detecting jump power changes can lead to jump hacks");
                Flaws++;
            }
            if (!NoclipDetection)
            {
                Output("Not detecting humanoid states can lead to noclip hacks");
                Flaws++;
            }
            if (!FPSUnlockDetection)
            {
                Output("Detecting players FPS being above 62 are signs of FPS Unlockers commonly found in paid exploits");
                Flaws++;
            }
            if (!HipHeightDetection)
            {
                Output("Not detecting hip height can lead to fly hacks");
                Flaws++;
            }
            if (!GodmodeDetection)
            {
                Output("Not detecting health increases or humanoid replacings can lead to godmode hacks");
                Flaws++;
            }
            if (!ChangesDetection)
            {
                Output("Not detecting changes of instances can lead to unexpected tampering behaviour");
                Flaws++;
            }
            if (!DisabledDetection)
            {
                Output("Not detecting script disabled attribute can lead to anti-exploits being easily shutdown");
                Flaws++;
            }
            Output("\n Amount of flaws found: " + Flaws);
            Output(" Amount of variables: " + Defined.Length);
            Output(" Script Security Score: " + (100 - (Flaws*100 / lines.Length*100)/100)+"%");
        }
    }
}
